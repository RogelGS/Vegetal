export class Vegetal {
    id: number;
    nombre: String;
    calorias: number;
    precio: number;
    color: String;
}